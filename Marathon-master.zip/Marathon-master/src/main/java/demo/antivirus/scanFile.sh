#!/bin/sh
echo "Scanning File of Type $1 with Name $2 of User $3"
# TODO: simulate a script that checks uploads for viruses
exit 0
