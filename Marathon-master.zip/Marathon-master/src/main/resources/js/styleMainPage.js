$(function() {
    $("#searchField").attr("placeholder", "name part");
});
