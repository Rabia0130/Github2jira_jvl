docker run -it --rm --name marathon-swat -p 8777:8080 marathon:swat
