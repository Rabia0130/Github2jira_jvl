docker pull cschneider4711/marathon:swat
docker run -it --rm --name marathon-swat -p 8777:8080 cschneider4711/marathon:swat
