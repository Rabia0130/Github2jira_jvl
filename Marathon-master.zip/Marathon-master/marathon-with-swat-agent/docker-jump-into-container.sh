docker exec -it marathon-swat /bin/bash
